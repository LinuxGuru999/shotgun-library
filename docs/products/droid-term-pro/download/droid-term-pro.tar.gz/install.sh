#!/bin/sh
set -e
cp bin/droid-term-pro.js /usr/local/bin/droid-term-pro.js
chmod 755 /usr/local/bin/droid-term-pro.js
echo "Installed droid-term-pro.js"
