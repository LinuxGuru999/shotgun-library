#!/bin/sh
set -e
cp bin/no-ops-starter-kit.js /usr/local/bin/no-ops-starter-kit.js
chmod 755 /usr/local/bin/no-ops-starter-kit.js
echo "Installed no-ops-starter-kit.js"
