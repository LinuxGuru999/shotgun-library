#!/bin/sh
set -e
cp bin/logcat-insight.js /usr/local/bin/logcat-insight.js
chmod 755 /usr/local/bin/logcat-insight.js
echo "Installed logcat-insight.js"
