#!/bin/sh
set -e
cp bin/privacy-toolkit.js /usr/local/bin/privacy-toolkit.js
chmod 755 /usr/local/bin/privacy-toolkit.js
echo "Installed privacy-toolkit.js"
